<!DOCTYPE html>
<html lang='en'>

<head>
  <meta charset='utf-8' />
  <script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.5/index.global.min.js'></script>

  <style>
    html,
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, Helvetica, sans-serif;
      font-size: 14px;

    }

    #calendar {
      max-width: 900px;
      margin: 40px auto;

    }
  </style>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js"></script>
  <!-- Bootstrap -->

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        Plugin: ['dayGrid', 'interaction', 'timeGrid', 'list'],
        headerToolbar: {
          // left: 'prev,next today miBoton',
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        // customButtons: {
        //   miBoton: {
        //     text: "Boton",
        //     click: function() {
        //       // alert('hola mundo');
        //       $('#exampleModal').modal('toggle');
        //     }
        //   }
        // },
        dateClick: function(info) {
          $('#exampleModal').modal('toggle');
          // console.log(info);

          calendar.addEvent({
            title: "evento n",
            date: info.dateStr
          });
        },
        eventClick: function(info) {
          console.log(info.event.title);
          console.log(info.event.start);
          console.log(info.event.extendedProps.pruebaDescripcion);
          
        },

        events:[
          {
            title:'aa',
            start:'2023-03-31',
            pruebaDescripcion:'Hoola mundo'
          }
        ]
      });
      //calendar.setOption('locale', 'ES')
      calendar.render();
    });
  </script>
</head>

<body>

  <div id='calendar'></div>


  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Titulo algo</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <div class="modal-body">
          ...aqui va lo que necesito hacer...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
          <button type="button" class="btn btn-primary">Guardar</button>
        </div>
      </div>
    </div>
  </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\calendarioLaravel\resources\views/calendario.blade.php ENDPATH**/ ?>